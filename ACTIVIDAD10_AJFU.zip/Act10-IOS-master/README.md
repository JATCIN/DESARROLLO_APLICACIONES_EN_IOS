# Act10-IOS
Proyecto de XCode correspondiente a la actividad 10 de la materia "Desarrollo de aplicaciones en plataforma iOS"
